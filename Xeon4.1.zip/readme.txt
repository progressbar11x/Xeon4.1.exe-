llll               llll         eeeeeeeee    ooooooo     nnnnnnnnn
    llll        llll            e                     o            o      n                n
        llllllll                eeeeeeeee   o             o     n                n
    llll        llll            e                     o             o     n                n
llll                llll        eeeeeeeee    ooooooo     n                n
-------------------------------------------------------------------------------------Xeon4.1 
damged is computing dead
like windows 10x wipet nofilefound
oh no we have
 
win7 win8 win8.1 win10
32bit-64bit
your trojan new                  
